<?php

namespace WP_Arvan\OBS\Admin\Controllers;

use WP_Arvan\OBS\Helper;
use WP_Arvan\OBS\S3Singletone;

class BucketTransferController
{
    public  $s3_client;
    private $wp_upload_folder;
    public function __construct()
    {
        $this->s3_client = (S3Singletone::get_instance())->get_s3client();
        $this->wp_upload_folder = wp_upload_dir(null,true)['basedir'] . '/wp-arvan-transfer/';
        $this->check_folder_exists();
    }

    public function check_folder_exists(){
        if( !file_exists($this->wp_upload_folder) ){
            mkdir($this->wp_upload_folder);
        }
    }
    public function get_bucket_list()
    {

        $list_response = $this->s3_client->listBuckets();
        return $list_response[ 'Buckets' ];
    }

    public function control(){

        if(isset($_POST['acs-move-bucket'])){
            $this->process_form();
        }

        if( isset($_POST['acs-rewrite-url'])){
            $this->rewrite_file_urls();
        }

    }

    public function process_form(){


        $from   = $_POST['bucket-files-transfer-from'] ?? null;
        $to     = $_POST['bucket-files-transfer-to'] ?? null;

        if(empty($from) || empty($to))
            return;

        if( 'null' == $from || 'null' == $to)
        {
            Helper::show_admin_notice(__('Values should not be empty'));
            return;
        }

        if($from == $to){
            Helper::show_admin_notice(__('Source and destination could not be same'));
            return;
        }


//       if(!$this->is_disk_space_enough($from))
//       {
//           Helper::show_admin_notice(__('Not enough space available in local disk'));
//           return;
//       }

        $this->do_transfer_from_source_to_destination($from, $to);

    }


    private function is_disk_space_enough($from){
        $head = $this->s3_client->headBucket([
            'Bucket' => $from,
        ]);

        $bucket_size = ($head['@metadata']['headers']['x-rgw-bytes-used'])??null;

        if(!$bucket_size)
            return false;

        if($from <= disk_free_space('.'))
            return true;
    }

    public function do_transfer_from_source_to_destination($from, $to){

        $source_files = $this->get_bucket_files_list($from);
        $destination_files = $this->get_bucket_files_list($to);

        foreach ($source_files as $file){
            $this->s3_client->copyObject([
                'Bucket' => $to,
                'CopySource' => "$from/$file",
                'Key' => "$file",
                'ACL'        => 'public-read'
            ]);
        }

    }

    public function rewrite_file_urls(){


        $args = array(
            'post_type'=> 'attachment',
            'post_status' => 'any',
            'orderby'=>'ID'
        );

        $result = new \WP_Query( $args );
        $posts = [];
        $bucket_url = Helper::get_storage_url();

        if($result-> have_posts()){
            while ($result->have_posts()){
                $result->the_post();
                $guid = get_the_guid();
                $post = new \stdClass();
                $post->id = get_the_ID();
                $post->guid = wp_basename($guid);
                $post->url = mb_substr( $guid, 0, mb_strrpos($guid, '/')  ) . '/';
                $posts[] = $post;
                update_post_meta(get_the_ID(), 'acs_storage_file_url', $bucket_url);

            }
        }
        wp_reset_postdata();


    }

    public function get_bucket_files_list($bucket){

        $file_list = $this->s3_client->getIterator('ListObjectsV2',  ['Bucket'=>$bucket]);

        $file_names = [];
        foreach($file_list as $file){
//            $acl = $this->s3_client->getObjectAcl(array('Bucket'=> $bucket, 'Key'=>$file['Key']));
//            var_dump($acl);
//            die();
            $file_names[] = $file['Key'];
        }
        return $file_names;
    }

}

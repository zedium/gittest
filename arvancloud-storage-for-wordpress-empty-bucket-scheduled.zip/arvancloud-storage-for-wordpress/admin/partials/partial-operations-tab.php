<?php


if ( ! defined( 'WPINC' ) ) {
	die;
}
use WP_Arvan\OBS\Admin\Controllers\BucketTransferController;
use WP_Arvan\OBS\Helper;
?>

<div class="obs-box-outline-title mb-4">
    <?php _e( 'Operations', 'arvancloud-object-storage' ) ?>
</div>

<form method="post">
    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( "Move files between buckets", 'arvancloud-object-storage' ) ?>
            </div>
            <div class="obs-box-outline-desc">
                <?php  _e( 'Move files between bucket. make sure have enough space in local host. Source bucket files will be last', 'arvancloud-object-storage' ) ?>
            </div>
        </div>
        <div>
            <div class="rtl">
                <?php
                $buckets = (new BucketTransferController())->get_bucket_list();
                if(is_array($buckets) && count($buckets)>1){
                    ?>
                    <span><?php _e('Copy from:', 'arvancloud-object-storage'); ?></span>

                    <select name="bucket-files-transfer-from">
                        <?php
                        echo '<option value="null">' . __('Source Bucket', 'arvancloud-object-storage') . '</option>';
                        foreach($buckets as $bucket){
                            echo "<option name='{$bucket['Name']}'>{$bucket['Name']}</option>";
                        }
                        ?>
                    </select>
                    <span><?php _e('To:', 'arvancloud-object-storage'); ?></span>
                    <select name="bucket-files-transfer-to">
                        <?php
                        echo '<option value="null">' . __('Destination Bucket', 'arvancloud-object-storage') . '</option>';
                        foreach($buckets as $bucket){
                            echo "<option name='{$bucket['Name']}'>{$bucket['Name']}</option>";
                        }
                        ?>
                    </select>
                    <?php
                }else{
                    echo '<h3>You have only one butcket.</h3>';
                }
                ?>

            </div>
        </div>
        <button type="submit" class="obs-btn-primary" name="acs-move-bucket" value="1">
            <?php  _e( 'Move', 'arvancloud-object-storage' ) ?>
        </button>
    </div>
</form>

<form method="post">
    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( "Rewrite URLs", 'arvancloud-object-storage' ) ?>
            </div>
            <div class="obs-box-outline-desc">
                <?php  _e( 'Rewrite URLs to selected bucket', 'arvancloud-object-storage' ) ?>
            </div>
        </div>
        <div>
            <div class="rtl">
                <?php
                $buckets = (new BucketTransferController())->get_bucket_list();
                if(is_array($buckets)){
                    ?>
                    <span><?php _e('Current Bucket:', 'arvancloud-object-storage'); ?></span>
                    <!-- this is just for showin current bucket name, it's not used anywhere -->
                    <select name="current-bucket-name">
                        <?php
                        $current_bucket = Helper::get_bucket_name();
                        echo "<option value='{$current_bucket}'>{$current_bucket}</option>";
                        ?>
                    </select>

                    <?php
                }
                ?>

            </div>
        </div>
        <button type="submit" class="obs-btn-primary" name="acs-rewrite-url">
            <?php  _e( 'Rewrite', 'arvancloud-object-storage' ) ?>
        </button>
    </div>
</form>

<form method="post">

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Upload', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php _e( 'Send all local media files to the desired bucket at once', 'arvancloud-object-storage' ) ?></div>
        </div>
        <div>
            <button class="obs-btn-primary-outline" id="bulk_upload">
                <?php _e( 'Bulk Upload', 'arvancloud-object-storage' ) ?>
            </button>
        </div>
    </div>

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Delete local files', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php _e( 'Delete all local files', 'arvancloud-object-storage' ) ?></div>
        </div>
        <div>
            <a class="obs-btn-primary-outline"
               href="<?php echo admin_url( '/admin.php?page=wp-arvancloud-storage&action=delete-local-files' ) ?>"><?php echo __( "Delete", 'arvancloud-object-storage' ) ?></a>

        </div>
    </div>

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Empty the current bucket', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php _e( 'Delete all the files in the current bucket', 'arvancloud-object-storage' ) ?></div>
        </div>
        <div>
            <a class="obs-btn-primary-outline" onclick="return false" id="btn-clear-current-bucket"
               href="<?php echo admin_url( '/admin.php?page=wp-arvancloud-storage&action=empty-current-bucket' ) ?>"><?php echo __( "Empty it", 'arvancloud-object-storage' ) ?></a>

        </div>
    </div>

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Download', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php _e( 'Get all the files from the desired bucket at once and save them locally', 'arvancloud-object-storage' ) ?></div>
        </div>
        <div>
            <button class="obs-btn-primary-outline" id="bulk_download">
                <?php _e( 'Bulk Download', 'arvancloud-object-storage' ) ?>
            </button>
        </div>
    </div>
</form>
<script>
    jQuery(document).ready(function(){
        jQuery('#btn-clear-current-bucket').on('click', function(e){
            jQuery.ajax({
                url: acs_media.ajax_url,
                data: {
                    'action': 'empty_bucket_modal',

                    '_nonce': acs_media.nonces.generate_acl_url
                },
                success:function(data) {
                    clear_bucket_response_handler(data,e);
                }
            })
        });
    });

    function clear_bucket_response_handler(response,e){
        if(response) {


            jQuery('#wpbody-content .arvan-card #form-empty-bucket').remove();
            jQuery('#wpbody-content .arvan-card').append(response);
            ar_open_modal(e, '#form-empty-bucket');
        }
    }
</script>

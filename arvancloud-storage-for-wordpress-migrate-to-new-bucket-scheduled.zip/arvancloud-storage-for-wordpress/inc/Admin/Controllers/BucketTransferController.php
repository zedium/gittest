<?php

namespace WP_Arvan\OBS\Admin\Controllers;

use WP_Arvan\OBS\Helper;
use WP_Arvan\OBS\Kueue\KueueCore;
use WP_Arvan\OBS\S3Singletone;

class BucketTransferController
{
    public  $s3_client;
    private $wp_upload_folder;
    const PAGE_LIMIT = 100;
    public function __construct()
    {
        $this->s3_client = (S3Singletone::get_instance())->get_s3client();
        $this->wp_upload_folder = wp_upload_dir(null,true)['basedir'] . '/wp-arvan-transfer/';
        $this->check_folder_exists();
        add_action('obs_do_transfer_from_source_to_destination', array($this, 'do_transfer_from_source_to_destination'),10,4);
        add_action('obs_rewrite_file_urls', array($this, 'rewrite_file_urls'),10,1);


    }

    public function check_folder_exists(){
        if( !file_exists($this->wp_upload_folder) ){
            mkdir($this->wp_upload_folder);
        }
    }
    public function get_bucket_list()
    {

        $list_response = $this->s3_client->listBuckets();
        return $list_response[ 'Buckets' ];
    }

    public function control(){

        if(isset($_POST['acs-move-bucket'])){
            $this->process_form();
        }

        if( isset($_POST['acs-rewrite-url'])){
            $this->rewrite_file_urls();
        }

    }

    public function process_form(){


        $from   = $_POST['bucket-files-transfer-from'] ?? null;
        $to     = $_POST['bucket-files-transfer-to'] ?? null;

        if(empty($from) || empty($to))
            return;

        if( 'null' == $from || 'null' == $to)
        {
            Helper::show_admin_notice(__('Values should not be empty',  'arvancloud-object-storage'));
            return;
        }

        if($from == $to){
            Helper::show_admin_notice(__('Source and destination could not be same',  'arvancloud-object-storage'));
            return;
        }

        if( (KueueCore::get_instance())->has_pending_job('obs_do_transfer_from_source_to_destination') )
        {
            Helper::show_admin_notice(__('Already has pending task',  'arvancloud-object-storage'));
            return;
        }

        $total_source_files = $this->get_bucket_all_files($from);
        $limitation_separator_key = [];

        $i=1;
        foreach($total_source_files as $source_file){
            if( ($i ==1) || ($i % self::PAGE_LIMIT) == 0 ){
                $limitation_separator_key[] = $source_file;
            }
            $i++;
        }


        $kueue = KueueCore::get_instance();

        $i = 1;
        foreach ($limitation_separator_key as $item){

            $arg = array($from, $to, $item, $i);

            $kueue->add_job( time() + ($i * MINUTE_IN_SECONDS) ,0,'obs_do_transfer_from_source_to_destination',$arg);
            $i++;
        }
        $kueue->add_job(time() + (MINUTE_IN_SECONDS * $i), 0, 'obs_rewrite_file_urls', array($to) );

        $kueue->schedule_jobs();

        Helper::show_admin_notice(__('Task successfully scheduled',  'arvancloud-object-storage'), 'notice-success');

    }



    public  function do_transfer_from_source_to_destination($from, $to, $separator_key, $index){



        ini_set('max_execution_time', MINUTE_IN_SECONDS * 3);
        $source_files = $this->get_bucket_files_list($from, $separator_key, $index);

        if(!$source_files)
            return false;

        foreach ($source_files as $file){
            $this->s3_client->copyObject([
                'Bucket' => $to,
                'CopySource' => "$from/$file",
                'Key' => "$file",
                'ACL'        => 'public-read'
            ]);
        }
        return true;
    }

    public function rewrite_file_urls($bucketname){


        $args = array(
            'post_type'=> 'attachment',
            'post_status' => 'any',
            'orderby'=>'ID'
        );

        $result = new \WP_Query( $args );
        $posts = [];
        $bucket_url = Helper::get_storage_url_by_bucket_name($bucketname);

        if($result-> have_posts()){
            while ($result->have_posts()){
                $result->the_post();
                $guid = get_the_guid();
                $post = new \stdClass();
                $post->id = get_the_ID();
                $post->guid = wp_basename($guid);
                $post->url = mb_substr( $guid, 0, mb_strrpos($guid, '/')  ) . '/';
                $posts[] = $post;
                update_post_meta(get_the_ID(), 'acs_storage_file_url', $bucket_url);

            }
        }
        wp_reset_postdata();


    }

    public function get_bucket_files_list($bucket, $separator_key, $index){

        if($index == 1)
            $args = ['Bucket'=>$bucket, 'list-type'=>2, 'MaxKeys'=> self::PAGE_LIMIT];
        else
            $args = ['Bucket'=>$bucket, 'list-type'=>2, 'StartAfter'=> $separator_key, 'MaxKeys'=> self::PAGE_LIMIT];

        $result = $this->s3_client->listObjectsV2( $args );

        $data = $result['Contents']??null;

        if(!$data)
            return false;

        $file_names = [];
        foreach($data as $file){
            $file_names[] = $file['Key'];
        }

        return $file_names;
    }

    public function get_bucket_all_files($bucket){
        $s3client = (S3Singletone::get_instance())->get_s3client();
        $results = $s3client->getPaginator('ListObjectsV2', [
            'Bucket' => $bucket
        ]);

        $keys = array();

        foreach ($results->search('Contents[].Key') as $key) {
            $keys[] = $key;
        }

        return $keys;
    }

    public function has_pending_task(){
        return ( true == (KueueCore::get_instance())->has_pending_job()) ? __('Has pending task', 'arvancloud-object-storage') : __('No pending task','arvancloud-object-storage');
    }

}

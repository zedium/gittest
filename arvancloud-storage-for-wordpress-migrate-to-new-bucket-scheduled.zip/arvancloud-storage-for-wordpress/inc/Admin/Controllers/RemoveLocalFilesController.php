<?php

namespace WP_Arvan\OBS\Admin\Controllers;

use WP_Arvan\OBS\Admin\Partials;
use WP_Arvan\OBS\Helper;

class RemoveLocalFilesController
{
    private static $instance;

    public function __construct()
    {
        if ( ! defined( 'WPINC' ) ) {
            die;
        }
    }

    public static function get_instance()
    {

        if (null == self::$instance) {
            self::$instance = new RemoveLocalFilesController();
        }
        return self::$instance;
    }

    public function control()
    {

        if(isset( $_GET['success']) && (isset($_GET['action']) && 'delete-local-files' == $_GET['action']) )
        {
            Helper::show_admin_notice(__('Successfully deleted.'), 'notice-success');
        }

        if ('post' == strtolower($_SERVER['REQUEST_METHOD']) && (isset($_GET['action']) && 'delete-local-files' == $_GET['action'])) {

            $posts = $this->get_deletable_posts();
            $upload_dir = wp_upload_dir()['basedir'] . DIRECTORY_SEPARATOR;

            foreach ($posts as $post) {

                if (!$post->should_delete)
                    continue;
                if (is_array($post->attachments) && isset($post->attachments['file'])) {

                    $file_name = $post->attachments['file'];

                    $sub_attachment_path = $upload_dir . dirname($file_name) . DIRECTORY_SEPARATOR;

                    if (file_exists($upload_dir . $file_name)) {


                        unlink($upload_dir . $file_name);
                    }

                    if (is_array($post->attachments['sizes'])) {

                        foreach ($post->attachments['sizes'] as $key => $value) {

                            if (file_exists($sub_attachment_path . $value['file'])) {

                                unlink($sub_attachment_path . $value['file']);
                            }

                        }
                    }
                }

            }

            wp_redirect('admin.php?page=wp-arvancloud-storage&action=delete-local-files&success=true');

        }
    }

    public function render_view()
    {

        Partials::remove_local_files();

    }


    public function process()
    {
        if ('get' == strtolower($_SERVER['REQUEST_METHOD']) && (isset($_GET['action']) && 'delete-local-files' == $_GET['action'])) {
            $this->render_view();


        }
    }

    function get_deletable_posts()
    {
        $args = array(
            'post_type' => 'attachment',
            'post_status' => 'any',
            'orderby' => 'ID'
        );

        $result = new \WP_Query($args);
        $posts = [];

        if ($result->have_posts()) {
            while ($result->have_posts()) {
                $result->the_post();
                $post_id = get_the_ID();

                $post = new \stdClass();
                $post->id = $post_id;


                $should_delete = get_metadata('post', $post_id, 'acs_storage_file_url', true);
                $post->should_delete = empty($should_delete) ? false : true;

                $post->attachments = wp_get_attachment_metadata($post_id);
                $posts[] = $post;

            }
        }

        wp_reset_postdata();

        return $posts;
    }
}

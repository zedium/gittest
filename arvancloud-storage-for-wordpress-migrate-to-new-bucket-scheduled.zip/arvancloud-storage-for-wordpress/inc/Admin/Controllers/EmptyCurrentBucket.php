<?php

namespace WP_Arvan\OBS\Admin\Controllers;

use WP_Arvan\OBS\Helper;
use WP_Arvan\OBS\Admin\Partials;
use WP_Arvan\OBS\S3Singletone;

class EmptyCurrentBucket
{
    private static $instance;
    private $s3client;

    public function __construct()
    {
        if ( ! defined( 'WPINC' ) ) {
            die;
        }
        $this->s3_client = (S3Singletone::get_instance())->get_s3client();
    }

    public static function get_instance()
    {

        if (null == self::$instance) {
            self::$instance = new EmptyCurrentBucket();
        }
        return self::$instance;
    }

    public function render_view()
    {

        Partials::empty_current_bucket();
        wp_die();

    }
    public function control(){
        if ('post' == strtolower($_SERVER['REQUEST_METHOD']) ) {
            if($this->do_empty_current_bucket()) {
                wp_send_json_success( array(
                    'success'=>'true',
                    'message'=>__('Successfully cleared', 'arvancloud-object-storage')
                ),200);
                return;
            }else{
                wp_send_json_error(array(
                    'success'=>'false',
                    'message'=> __('Failed', 'arvancloud-object-storage')

                ));
            }
        }
        if ('get' == strtolower($_SERVER['REQUEST_METHOD']) && (isset($_GET['notice']) && 'empty-current-bucket-successful' == $_GET['notice'])) {
            Helper::show_admin_notice(__('Sucessfully deleted','arvancloud-object-storage'), 'notice-success');
        }

    }
    public function do_empty_current_bucket(){

        ini_set('max_execution_time', MINUTE_IN_SECONDS * 10);
        try {
            $bucket_name = Helper::get_bucket_name();
            $objects = $this->s3_client->getIterator('ListObjects', array(
                "Bucket" => $bucket_name,
            ));
            foreach ($objects as $object) {
                $this->s3_client->deleteObject(array(
                        'Bucket' => $bucket_name,
                        'Key' => $object['Key'])
                );
            }
            return true;
        }catch (\Exception $error){
            return false;
        }
        

    }

}

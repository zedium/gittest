<?php

namespace WP_Arvan\OBS;

use Aws\S3\S3Client;
use WP_Arvan\OBS\Helper;

class S3Singletone
{
    private static  $instance;
    private         $s3_client;

    public function __construct(){

        $credentials = Helper::get_storage_settings();

        $this->s3_client = new S3Client([
            'region'   => '',
            'version'  => '2006-03-01',
            'endpoint' => $credentials['endpoint-url']??'https://s3.ir-thr-at1.arvanstorage.com',
            'use_aws_shared_config_files' => false,
            'credentials' => [
                'key'     => $credentials['access-key']??'key',
                'secret'  => $credentials['secret-key']??'secret'
            ],
            // Set the S3 class to use objects. arvanstorage.com/bucket
            // instead of bucket.objects. arvanstorage.com
            'use_path_style_endpoint' => true
        ]);

    }
    public static function get_instance(){

        if( !self::$instance )
            self::$instance = new S3Singletone();

        return self::$instance;

    }

    public function get_s3client(){
        return $this->s3_client;
    }
}

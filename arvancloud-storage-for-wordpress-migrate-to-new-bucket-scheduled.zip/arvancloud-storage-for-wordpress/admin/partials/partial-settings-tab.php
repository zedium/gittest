<?php

use WP_Arvan\OBS\Helper;
use WP_Arvan\OBS\Admin\Admin;

if ( ! defined( 'WPINC' ) ) {
	die;
}


if( $acs_settings_option = Helper::get_storage_settings() ) {
    $config_type         = $acs_settings_option['config-type'];
    $snippet_defined     = defined( 'ARVANCLOUD_STORAGE_SETTINGS' );
    $db_defined          = $config_type == 'db' && ! empty( $acs_settings_option['access-key'] ) && ! empty( $acs_settings_option['secret-key'] ) && ! empty( $acs_settings_option['endpoint-url'] ) ? true : false;
    $bucket_selected     = Helper::get_bucket_name();
    $acs_settings	     = get_option( 'acs_settings' );

}

require( ACS_PLUGIN_ROOT . 'inc/s3client.php' );
try {
    $result = $client->headBucket([
        'Bucket' => $bucket_selected,
    ]);

    $list_response = $client->listBuckets();
    $buckets       = $list_response[ 'Buckets' ];

} catch (Aws\Exception\AwsException $e) {
    echo 'Error: ' . $e->getAwsErrorMessage();
}

if ( $result ) {
    $used = Admin::formatBytes($result['@metadata']['headers']['x-rgw-bytes-used']);
    $object_count = $result['@metadata']['headers']['x-rgw-object-count'];
}

?>

<div class="obs-box-outline-title mb-4">
    <?php _e( 'Settings', 'arvancloud-object-storage' ) ?>
</div>

<form method="post">

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Provider', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php echo Helper::get_storage_url() ?></div>
        </div>
        <div>
            <a class="obs-btn-primary-outline"
                href="<?php echo admin_url( '/admin.php?page=wp-arvancloud-storage&action=change-access-option' ) ?>"><?php _e( 'Change Provider', 'arvancloud-object-storage' ) ?></a>
        </div>
    </div>

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( 'Bucket: ', 'arvancloud-object-storage' ) ?></div>
            <div class="obs-box-outline-desc"><?php echo Helper::get_bucket_name() ?></div>
        </div>
        <div>
            <?php
            if ( $result ) {
                ?>
            <span class="obs-badge obs-badge-gray me-2">
                <?php echo $used ?>
            </span>
            <span class="obs-badge obs-badge-gray me-3">
                <?php echo $object_count . ' ' . __('Objects', 'arvancloud-object-storage') ?>
            </span>
            <?php
            }
            ?>
            <a class="obs-btn-primary-outline"
                href="<?php echo admin_url( '/admin.php?page=wp-arvancloud-storage&action=change-bucket' ) ?>"><?php echo __( "Change Bucket", 'arvancloud-object-storage' ) ?></a>
        </div>
    </div>

    <div class="obs-box-outline d-flex align-items-center justify-content-between">
        <div>
            <div class="obs-box-outline-title"><?php _e( "Keep local files", 'arvancloud-object-storage' ) ?>
            </div>
            <div class="obs-box-outline-desc">
                <?php  _e( 'Keep local files after uploading them to storage.', 'arvancloud-object-storage' ) ?>
            </div>
        </div>
        <div>
            <div class="obs-form-toggle">
                <input class="obs-input" type="checkbox" name="keep-local-files" id="keep-local-files" value="1"
                    <?php echo ( !isset($acs_settings['keep-local-files']) || $acs_settings['keep-local-files']) ? 'checked' : '' ?>>
                <div class="obs-custom-input"></div>
            </div>
        </div>
    </div>



    <div class="d-flex justify-left mt-4">
        <button type="submit" class="obs-btn-primary" name="acs-settings" value="1">
            <?php  _e( 'Save', 'arvancloud-object-storage' ) ?>
        </button>
    </div>

</form>
<br />




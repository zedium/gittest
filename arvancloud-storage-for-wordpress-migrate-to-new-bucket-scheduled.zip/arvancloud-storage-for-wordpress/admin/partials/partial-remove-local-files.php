<div class="wrap">
    <div class="arvan-wrapper">
        <div class="arvan-card">
            <div class="obs-box-outline-title mb-4">
                <?php _e('Delete local files', 'arvancloud-object-storage') ?>
            </div>
            <form method="post" id="form-delete-local-files">
                <div class="obs-content-wrapper">
                    <div class="obs-box-outline d-flex items-center justify-center">
                    <div class="obs-modal obs-modal-alert">
                        <div class="obs-modal-title"><p class="obs-modal-desc"><?php _e('Caution', 'arvancloud-object-storage'); ?></p></div>
                        <figure class="obs-modal-figure">
                            <svg class="icon" width="48" height="48" viewBox="0 0 48 48" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M20.5796 7.7209L3.63955 36.0009C3.29029 36.6057 3.10549 37.2915 3.10353 37.9899C3.10158 38.6884 3.28254 39.3752 3.62841 39.9819C3.97428 40.5887 4.473 41.0944 5.07497 41.4486C5.67693 41.8028 6.36115 41.9932 7.05955 42.0009H40.9396C41.638 41.9932 42.3222 41.8028 42.9241 41.4486C43.5261 41.0944 44.0248 40.5887 44.3707 39.9819C44.7166 39.3752 44.8975 38.6884 44.8956 37.9899C44.8936 37.2915 44.7088 36.6057 44.3596 36.0009L27.4196 7.7209C27.063 7.13311 26.561 6.64714 25.9619 6.30987C25.3629 5.97259 24.687 5.79541 23.9996 5.79541C23.3121 5.79541 22.6362 5.97259 22.0372 6.30987C21.4381 6.64714 20.9361 7.13311 20.5796 7.7209V7.7209Z"
                                      stroke="#EE5353" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M24 18V26" stroke="#EE5353" stroke-width="4" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                                <path d="M24 34.0002H24.02" stroke="#EE5353" stroke-width="4" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                            </svg>
                        </figure>
                        <div class="obs-modal-desc"><?php _e('Delete all local files', 'arvancloud-object-storage'); ?></div>
                        <div class="obs-modal-desc-small"><?php _e('All files in your local storage will be deleted', 'arvancloud-object-storage'); ?></div>
                        <div class="obs-modal-confirm d-flex items-center justify-center">
                            <div class="obs-form-check">
                                <input class="obs-input" type="checkbox" name="exampleRadios" id="accept-delete-risk"
                                       value="option1">
                                <div class="obs-custom-input"></div>
                            </div>
                            <label for="modal"><?php _e('I\'m sure of deleting files', 'arvancloud-object-storage'); ?></label>
                        </div>
                        <div class="obs-modal-actions">
                            <a class="obs-btn-secondary-outline" href="<?php echo admin_url( '/admin.php?page=wp-arvancloud-storage&tab=operations' ) ?>"><?php _e('Cancel', 'arvancloud-object-storage') ?></a>
                            <input type="submit" name="submit-delete-local-files" class="obs-btn-danger" id="submit-delete-local-files" onclick="return false;" value="<?php _e('Delete all', 'arvancloud-object-storage'); ?>" />
                        </div>
                    </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function(){

        jQuery('#submit-delete-local-files').on('click', function (){
            $status = jQuery('#accept-delete-risk');
            if($status.prop('checked'))
                jQuery('#form-delete-local-files').submit();
        });

    });
</script>
